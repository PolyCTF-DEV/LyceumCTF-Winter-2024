from secret import flag
def process_string(input_string):
    def shift_char(c, shift):
        if c.isalpha():
            base = ord('A') if c.isupper() else ord('a')
            return chr((ord(c) - base + shift) % 26 + base)
        return c
    shifted_string = ''.join(shift_char(c, 6) for c in input_string[::-1])
    final_string = ''.join(c.lower() if c.isupper() else c.upper() for c in shifted_string)
    return final_string

input_string = flag
output = process_string(input_string)
with open("output.txt", "w") as f:
    f.write(output)
