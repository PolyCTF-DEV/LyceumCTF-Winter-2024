import base64
from secret import flag

def process_string(input_string):
    result = []
    key = 52 
    byte_array = input_string.encode()
    for byte in byte_array:
        xor_byte = byte ^ key
        base64_byte = base64.b64encode(bytes([xor_byte])).decode()
        result.append(base64_byte)
    return "".join(result)

input_string = flag
output = process_string(input_string)
with open("output.txt", "w") as f:
    f.write(output)
